<?php
/**
 * This file is information for Fallen theme
 *
 * @package Fallen
 * @author  Frans Allen
 * @link    https://www.fransallen.com
 */

// Theme info
$theme_name = 'Fallen';
$theme_full_version = '0.7';
