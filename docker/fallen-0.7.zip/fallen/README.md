>> NOTE: This repository is no longer updated. To download **Fallen**, See [phpMyAdmin Themes directory](https://www.phpmyadmin.net/themes/).

# Fallen (phpMyAdmin Theme)

A Beautiful phpMyAdmin theme. Designed for you.

<a href="https://www.marsble.com/d/2" target="_blank"><img src="https://www.marsble.com/images/buttons/btn_discuss.png" alt="Discuss on Marsble"></a>

## Usage

* Download Fallen.
* Unzip **fallen-master**.
* Rename **fallen-master** to **fallen**.
* Move to your phpMyAdmin themes directory.
* Activate "Fallen" from phpMyAdmin dashboard.
* Done.

## Version

[Fallen 0.3](https://files.phpmyadmin.net/themes/fallen/0.3/fallen-0.3.zip) for phpMyAdmin **4.6**

[Fallen 0.4](https://files.phpmyadmin.net/themes/fallen/0.3/fallen-0.4.zip) for phpMyAdmin **4.7**

> See all version in [phpMyAdmin Themes directory](https://www.phpmyadmin.net/themes/).

## Screenshot

![Fallen login](screen-3.png)

![Fallen home](screen.png)

![Fallen DB](screen-2.png)

## LICENSE

Licensed under GPL license. Please see the license file: https://github.com/fransallen/fallen/LICENSE
