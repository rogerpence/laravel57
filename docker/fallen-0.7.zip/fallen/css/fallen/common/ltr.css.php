/* LTR Mode */
