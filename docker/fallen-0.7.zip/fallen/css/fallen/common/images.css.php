img.lightbulb {
  cursor: pointer
}
