meter[value="1"]::-webkit-meter-optimum-value {
    background: linear-gradient(white 3%, #E32929 5%, transparent 10%, #E32929);
}

meter[value="2"]::-webkit-meter-optimum-value {
    background: linear-gradient(white 3%, #FF6600 5%, transparent 10%, #FF6600);
}

meter[value="3"]::-webkit-meter-optimum-value {
    background: linear-gradient(white 3%, #FFD700 5%, transparent 10%, #FFD700);
}