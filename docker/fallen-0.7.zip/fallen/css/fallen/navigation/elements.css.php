#pma_navigation div.pageselector {
  text-align: center;
  margin: 0;
  margin-left: 0.75em;
  border-left: 1px solid #666
}
